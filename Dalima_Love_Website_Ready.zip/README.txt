DALIMA LOVE WEBSITE ❤️

Folder structure:
Dalima_Love_Website_Ready/
├── index.html
└── images/
    ├── photo1.jpg
    ├── photo2.jpg
    ├── photo3.jpg
    ├── photo4.jpg
    ├── photo5.jpg
    └── photo6.jpg

To test on your phone:
1. Open index.html in SPCK.
2. Use SPCK Preview / Open in Browser.
3. Keep the images folder beside index.html.

To publish:
Upload BOTH index.html and the images folder to your website/repository.
Do not rename the images unless you also change their names in the HTML.
